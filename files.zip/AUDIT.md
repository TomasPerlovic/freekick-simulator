# Audit and roadmap — Free Kick Simulator

Baseline taken from `freekick-simulator-main.zip` (2,904 lines: physics 906, render 587, app 741, tests 267).
Baseline tests: **29/29 pass**. Added in Stage 1: `tests/regression.test.js` (**9/9 pass**).
Run: `node tests/physics.test.js && node tests/regression.test.js`

## 1. Strengths to preserve
- `physics.js` is DOM-free, SI-unit, deterministic (seeded RNG), and runs in Node. This is the right foundation.
- RK4 at 1 kHz (~850 steps/ms in Node); tests check energy, momentum, terminal velocity, step convergence.
- Magnus force is perpendicular to velocity (does no work); Reynolds-dependent drag; spin decay (measured 6.2 %/s); Sutherland viscosity; ISA density with humidity.
- Rigid-sphere bounce couples linear and angular momentum; sliding-to-rolling transition is correct for a hollow shell.
- Zero dependencies, no build step, deployable as static files.

## 2. Findings

### Physics (ranked by scientific risk)
1. **Sub-critical drag constant needs verification.** `CD_SUB = 0.346`. A secondary source quoting Goff & Carré (2009) gives
   `Cd = a + b/(1+exp((v−vc)/vs))`, a = 0.155, b = 0.346, vc = 12.19 m/s, vs = 1.309 m/s, i.e. sub-critical Cd ≈ **0.50**.
   The engine's transition width (RE_WIDTH) and centre match that fit, and its super-critical 0.155 agrees with Goff & Carré (2012), who measured ≈ 0.17.
   The engine may have used `b` as the *total* sub-critical value. **Not confirmed against the primary paper** (paywalled; I could only read a student
   paper citing it and the 2012 open-access follow-up, which does not state the sub-critical value). Measured sensitivity: fast shots (>14 m/s throughout) barely
   change; a slow high lob's flight time moved 3.03 s → 3.42 s. Action: read the primary source, then change the constant *and* regenerate the golden values deliberately.
2. **One generic ball.** Cd/Cl/spin-decay/knuckle are one set of coefficients; README says they are "empirical fits", not measurements of a specific ball. Fine as a baseline, but the
   Ball Laboratory cannot honestly differentiate Jabulani vs Brazuca until per-ball parameter *ranges* are sourced (Asai et al. 2007; Barber & Carré 2010; Goff & Carré 2010).
3. **Lift curve** `Cl = S/(2.32 S + 0.4)` saturates sensibly (≈0.32 at S = 0.5, consistent with Goff & Carré's Teamgeist result of ≈0.35), but I could not attribute the exact form to a paper. Treat as "empirical, plausible", not "published".
4. **Knuckle model is phenomenological**: sum of two sinusoids in path length plus accumulated-rotation phase, amplitude 0.13 × spin-suppression × supercritical gate. Over 25 m at 31 m/s it produced a
   lateral crossing spread of sd 0.17 m (range ±0.24 m, 40 seeds). I did **not** verify whether that amplitude matches published knuckle measurements; it should be calibrated before being presented as realistic.
5. Wind is uniform with height (no boundary layer); the foot is not modelled (launch speed and spin are set directly); the keeper's "read" is a noise model, not perception science.

### Rendering
- Hand-written WebGL2: sky shader, analytic ground shadows (≤20 capsules; no shadow maps), Lambert + a crude specular term. No PBR, no IBL, no tone mapping, no shadows on stands/net.
- Stadium = 4 flat quads + procedural crowd shader; no floodlights, roof, or architecture. Goal net is a line grid (good deformation model, thin look).
- Ball shader draws the 12 pentagons only (no seams/hexagons, no panel normals). Ball orientation *is* driven by the integrated spin quaternion — keep that.
- Players are capsule figures.

### Application / architecture
- `app.js` is a 741-line IIFE mixing state, UI, charts, cameras and the loop; renderer and physics are cleanly separated, the app layer is not. Globals `FK`, `FKRender`, `FKSound`.
- 6 cameras; "follow" uses velocity direction with exponential smoothing and snaps when speed < 2.5 m/s; no offset control, no look-ahead, no scrub, pause-and-orbit only in Orbit mode.
- Per-frame allocations: `new Float32Array(sh)`/`(shp)` in the ground pass, ribbon colour closures and arrays in `buildRibbons`. Harmless today; will matter once more is drawn.
- No scene/cinematic timeline, no data layer, no ball-model abstraction.

### Performance
- Not measured in a browser (no headless GPU in this environment). Physics cost is negligible. Expected bottleneck is the ground fragment shader (20-iteration shadow loop + 2 noise octaves at full DPR ≤ 2).

### Missing vs the brief
Science Lab, Ball Lab, Experiment Lab, cinematic mode, 20-kick exhibition, force-vector overlays, impact model, bibliography, ball-specific parameters, camera set (goalkeeper, side, physics), fullscreen mode.

## 3. Roadmap (dependency-ordered)
| Stage | Deliverable | Gate |
|---|---|---|
| 1 ✅ | Audit, baseline, golden regression tests | 29 + 9 tests green |
| 2 | Split `app.js` into modules (state / cameras / charts / ui); camera system (keeper, side, physics, follow offset + look-ahead, scrub-and-orbit); ball panel geometry + seams; stadium pass | physics tests untouched; browser check at 1080p and a tablet size |
| 3 | `forces()` API on the engine returning gravity/drag/Magnus/knuckle vectors per step, so overlays consume real engine output | test: sum of returned forces / m == `_deriv` acceleration |
| 4 | Ball model registry with `{value, source, confidence}` per parameter; Ball Lab UI | no parameter without a citation or an explicit "estimated range" label |
| 5 | Experiment Lab (paired runs, overlays, graphs, CSV) | every comparison uses `Simulation` |
| 6 | Cinematic timeline engine, then Scene 1–6 for one kick | narration synced to engine time |
| 7 | Historical records (sourced facts only, estimates labelled), 3 case studies, then scale | each entry: citations; parameters tagged *estimate* |
| 8 | Optimisation, cross-browser, docs, bibliography | |

## 4. Risks
- Presenting un-sourced coefficients as measurements (mitigation: confidence tags, Stage 4).
- The 20-kick exhibition requires per-kick research and footage-informed estimates; this cannot be done responsibly in one pass.
- No browser available here: visual work must be verified by you in Chrome/Firefox/Safari until a headless runner exists.
